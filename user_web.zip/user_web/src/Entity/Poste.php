<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Poste
 *
 * @ORM\Table(name="poste")
 * @ORM\Entity
 */
class Poste
{
    /**
     * @var int
     *
     * @ORM\Column(name="id_poste", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idPoste;

    /**
     * @var string
     *
     * @ORM\Column(name="sujet_poste", type="string", length=200, nullable=false)
     */
    private $sujetPoste;

    /**
     * @var string
     *
     * @ORM\Column(name="nom_auteur", type="string", length=20, nullable=false)
     */
    private $nomAuteur;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date", nullable=false)
     */
    private $date;

    public function getIdPoste(): ?int
    {
        return $this->idPoste;
    }

    public function getSujetPoste(): ?string
    {
        return $this->sujetPoste;
    }

    public function setSujetPoste(string $sujetPoste): self
    {
        $this->sujetPoste = $sujetPoste;

        return $this;
    }

    public function getNomAuteur(): ?string
    {
        return $this->nomAuteur;
    }

    public function setNomAuteur(string $nomAuteur): self
    {
        $this->nomAuteur = $nomAuteur;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }
}
