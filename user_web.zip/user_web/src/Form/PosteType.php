<?php
namespace App\Form;

use App\Entity\Poste;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class PosteType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('sujetPoste', TextType::class, [
                'label' => 'Sujet du poste',
                'required' => true,
                'constraints' => [
                    new NotBlank(['message' => 'Le sujet du poste ne peut pas être vide.'])
                ]
            ])
            ->add('nomAuteur', TextType::class, [
                'label' => 'Nom de l\'auteur',
                'required' => true,
                'constraints' => [
                    new NotBlank(['message' => 'Le nom de l\'auteur ne peut pas être vide.'])
                ]
            ])
            ->add('date', DateType::class, [
                'label' => 'Date',
                'widget' => 'single_text',
                'required' => true,
                'constraints' => [
                    new NotBlank(['message' => 'La date ne peut pas être vide.'])
                ]
            ])
            ->add('enregistrer', SubmitType::class, [
                'label' => 'Enregistrer'
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Poste::class,
        ]);
    }
}
