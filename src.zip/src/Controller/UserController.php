<?php

namespace App\Controller;

use App\Entity\User;
use App\Form\UserType;
use App\Form\LoginFormType;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use ReCaptcha\ReCaptcha;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Security\Core\Exception\CustomUserMessageAuthenticationException;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;
class UserController extends AbstractController
{
    /**
     * @Route("/users", name="user_index", methods={"GET"})
     */
    public function index(UserRepository $userRepository): Response
    {
        $users = $userRepository->findAll();

        return $this->render('user/index.html.twig', [
            'users' => $users,
        ]);
    }

 /**
 * @Route("/users/new", name="user_new", methods={"GET","POST"})
 */
public function new(Request $request, ParameterBagInterface $params): Response
{
    $user = new User($params);
    $form = $this->createForm(UserType::class, $user);
    $form->handleRequest($request);

    if ($form->isSubmitted() && !$form->isValid()) {
        $this->addFlash('error', 'There was an error with your form submission.');
    }

    if ($form->isSubmitted() && $form->isValid()) {
        // Vérification de la validité de l'email
        if (!filter_var($user->getEmail(), FILTER_VALIDATE_EMAIL) || !strpos($user->getEmail(), '@')) {
            $this->addFlash('error', 'L\'adresse email n\'est pas valide.');
            return $this->redirectToRoute('user_new');
        }
        // Vérification de la validité du nom d'utilisateur
        if (!preg_match('/^[a-zA-Z]+$/', $user->getUsername())) {
            $this->addFlash('error', 'Le nom d\'utilisateur doit contenir uniquement des lettres.');
            return $this->redirectToRoute('user_new');
        }
        // Vérification de la validité du mot de passe
        if (strlen($user->getPassword()) < 8) {
            $this->addFlash('error', 'Le mot de passe doit contenir au moins 8 caractères.');
            return $this->redirectToRoute('user_new');
        }

        $entityManager = $this->getDoctrine()->getManager();

        // Vérification de l'existence de l'utilisateur
        $existingUser = $entityManager->getRepository(User::class)->findOneBy([
            'email' => $user->getEmail(),
            'username' => $user->getUsername(),
        ]);

        if ($existingUser !== null) {
            $this->addFlash('error', 'Un utilisateur avec cet email ou nom d\'utilisateur existe déjà.');
            return $this->redirectToRoute('user_new');
        }

        // Ajout des attributs role, session et photo à l'utilisateur
        $user->setuserType($form->get('userType')->getData());
        $session = $form->get('session')->getData();
        if (!empty($session)) {
            $user->setSession($session);
        }      $photos = $form->get('photo')->getData();
            
        if (is_array($photos)) {
            $filenames = [];
            foreach ($photos as $photo) {
                $filename = uniqid().'.'.$photo->getClientOriginalExtension();
                $photo->move($this->getParameter('photos_directory'), $filename);
                $filenames[] = $filename;
            }
            $user->setPhoto($filenames);
        } else {
            $user->setPhoto($photos);
        }
        
        $entityManager->persist($user);
        $entityManager->flush();

        $this->addFlash('success', 'L\'utilisateur a été créé avec succès.');

        return $this->redirectToRoute('login');
    }

    return $this->render('user/new.html.twig', [
        'user' => $user,
        'form' => $form->createView(),
    ]);
}



    /**
     * @Route("/users/{id_user}", name="user_show", methods={"GET"})
     */
    public function show(User $user): Response
    {
        return $this->render('user/show.html.twig', [
            'user' => $user,
        ]);
    }

   /**
 * @Route("/users/{id_user}/edit", name="user_edit", methods={"GET","POST"})
 */
public function edit(Request $request, User $user): Response
{
    $form = $this->createForm(UserType::class, $user);
    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        // Vérification de la validité de l'email
        if (!filter_var($user->getEmail(), FILTER_VALIDATE_EMAIL) || !strpos($user->getEmail(), '@')) {
            $this->addFlash('error', 'L\'adresse email n\'est pas valide.');
            return $this->redirectToRoute('user_edit', ['id_user' => $user->getIdUser()]);
        }
        // Vérification de la validité du nom
        
        $this->getDoctrine()->getManager()->flush();

        $this->addFlash('success', 'L\'utilisateur a été modifié.');

        return $this->redirectToRoute('user_index');
    }

    return $this->render('user/edit.html.twig', [
        'user' => $user,
        'form' => $form->createView(),
    ]);
}

    /**
 * @Route("/users/{id}/delete", name="user_delete")
 */
public function deleteUser(User $user): Response
{
    $entityManager = $this->getDoctrine()->getManager();
    $entityManager->remove($user);
    $entityManager->flush();

    $this->addFlash('success', 'L\'utilisateur a été supprimé avec succès.');

    return $this->redirectToRoute('user_index');
}
/**
     * @Route("/login", name="login")
     */
    public function login(Request $request): Response
    {
        // Créer un formulaire de connexion à partir de la classe LoginFormType
        $form = $this->createForm(LoginFormType::class);
    
        // Récupérer les erreurs d'authentification, le dernier nom d'utilisateur entré et le formulaire après une soumission invalide
        $form->handleRequest($request);
    
        if ($form->isSubmitted() && $form->isValid()) {
            // Récupérer les données du formulaire soumis
            $formData = $form->getData();
            $userType = $request->request->get('user_type');
            // Vérifier le reCAPTCHA
            /*$recaptcha_secret_key = $_ENV['GOOGLE_RECAPTCHA_SECRET'];
            $recaptcha_site_key = $_ENV['GOOGLE_RECAPTCHA_SITE_KEY'];
            $recaptcha = new ReCaptcha($recaptcha_secret_key);
            $resp = $recaptcha->verify($request->request->get('g-recaptcha-response'), $request->getClientIp());
    
            if (!$resp->isSuccess()) {
                $this->addFlash('danger', 'Le reCAPTCHA est invalide.');
                return $this->redirectToRoute('login');
            }*/
    
            // Récupérer l'utilisateur à partir de l'adresse e-mail saisie dans le formulaire
            $user = $this->getDoctrine()->getRepository(User::class)->findOneBy(['email' => $formData['email']]);
    
            // Vérifier si l'utilisateur existe et si le mot de passe est correct
           
    
            // Stocker le nom d'utilisateur et le rôle de l'utilisateur dans des variables de session
            $session = $request->getSession();
            $session->set('username', $user->getUsername());
            $session->set('password', $user->getPassword());

            $session->set('role', $userType);
            $logfile = fopen('login_log.txt', 'a');
    
            // Récupérer la date et l'heure de système
            $datetime = new \DateTime();
            $timestamp = $datetime->format('Y-m-d H:i:s');
                
            // Récupérer l'adresse IP de l'utilisateur
            $ip_address = $request->getClientIp();
                
            // Écrire les informations de connexion dans le fichier de journalisation
            $log_message = "L'utilisateur ".$formData['email']." s'est connecté avec succès le ".$timestamp." depuis l'adresse IP ".$ip_address.".\n";
            fwrite($logfile, $log_message);
                
            // Fermer le fichier de journalisation
            fclose($logfile);
            // Rediriger l'utilisateur en fonction de son rôle
            if ($userType === 'admin') {
                return $this->redirectToRoute('welcome');
            } else {
                return $this->redirectToRoute('user_profile');
            }
        }
    
        //$recaptcha_site_key = $_ENV['GOOGLE_RECAPTCHA_SITE_KEY'];
    
        return $this->render('user/log.html.twig', [
            'form' => $form->createView(),
            //'recaptcha_site_key' => $recaptcha_site_key,
            
        ]);
    }



/**
 * @Route("/welcome", name="welcome")
 */
public function welcome(): Response
{
    return $this->render('back/welcome.html.twig');
}
/**
 * @Route("/front", name="front")
 */
public function front(): Response
{
    return $this->render('front/front.html.twig');
}


/**
 * @Route("/about", name="about")
 */
public function about(): Response
{
    return $this->render('front/about.html.twig');
}

/**
 * @Route("/pricing", name="pricing")
 */
public function pricing(): Response
{
    return $this->render('front/pricing.html.twig');
}

/**
 * @Route("/why", name="why")
 */
public function why(): Response
{
    return $this->render('front/why.html.twig');
}

/**
 * @Route("/testimonial", name="testimonial")
 */
public function testimonial(): Response
{
    return $this->render('front/testimonial.html.twig');
}
/**
 * @Route("/back", name="back")
 */
public function back(): Response
{
    return $this->render('user/welcome.html.twig');
}
/**
 * @Route("/dash", name="dash")
 */
public function index3(): Response
{
    return $this->render('user/index3.html.twig');
}

/**
 * @Route("/logout", name="logout")
 */
public function logout(): Response
{
    // Redirige l'utilisateur vers la page de connexion
    return $this->redirectToRoute('login');
}
/**

*@Route("/profile", name="user_profile")
*/
public function profile(Request $request): Response
{
$session = $request->getSession();
$userType = $session->get('role'); // récupérer la valeur de la variable de session role

return $this->render('user/profile.html.twig', [
'user' => $this->getUser(),
'userType' => $userType, // passer la valeur de la variable de session en tant que variable locale
]);
}
/**
     * @Route("/empty", name="empty")
     */
    public function index2()
    {
        return $this->render('user/empty.html.twig');
    }
/**
 * @Route("/users/forgot-password", name="user_forgot_password", methods={"GET","POST"})
 */
public function forgotPassword(Request $request, UserRepository $userRepository, MailerInterface $mailer, EntityManagerInterface $entityManager, UserPasswordEncoderInterface $passwordEncoder): Response
{
    if ($request->isMethod('POST')) {
        $email = $request->request->get('email');

        $user = $userRepository->findOneBy(['email' => $email]);

        if ($user) {
            // Génération d'un nouveau mot de passe aléatoire
            $newPassword = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 10);

            // Envoi de l'e-mail contenant le nouveau mot de passe
            $email = (new Email())
                ->from('ounihamdi4@gmail.com')
                ->to($user->getEmail())
                ->subject('Nouveau mot de passe')
                ->html(
                    $this->renderView(
                        'user/forgot_password_email.html.twig',
                        ['newPassword' => $newPassword]
                    )
                );

            $mailer->send($email);

            // Modification du mot de passe dans la base de données
            $user->setPassword($newPassword);
            $entityManager->persist($user);
            $entityManager->flush();

            $this->addFlash('success', 'Un e-mail contenant votre nouveau mot de passe a été envoyé à l\'adresse ' . $user->getEmail());

            return $this->redirectToRoute('login');
        } else {
            $this->addFlash('error', 'L\'adresse e-mail que vous avez saisie ne correspond à aucun compte.');
        }
    }

    return $this->render('user/forgot_password.html.twig');
}
/*public function closeWindow(Request $request): Response
    {
        // Définir le délai d'inactivité de la souris en millisecondes
        $inactivityDelay = 30000;

        // Initialiser le minuteur d'inactivité de la souris
        $inactivityTimer = $this->get('session')->get('inactivityTimer', null);
        if ($inactivityTimer === null) {
            $inactivityTimer = time() + $inactivityDelay / 1000;
            $this->get('session')->set('inactivityTimer', $inactivityTimer);
        }

        // Réinitialiser le minuteur d'inactivité de la souris à chaque mouvement de la souris
        if ($request->isMethod('POST')) {
            $this->get('session')->set('inactivityTimer', time() + $inactivityDelay / 1000);
        }

        // Vérifier si le minuteur d'inactivité est expiré
        if (time() >= $inactivityTimer) {
            $this->get('session')->remove('inactivityTimer');
            return $this->render('user/log.html.twig');
        }

        return $this->render('user/profile.html.twig');
    }*/
/**
     * @Route("/users/{email}", name="user_recherche")
     */
    public function recherche(UserRepository $userRepository, string $email): Response
    {
        $user = $userRepository->findByEmail($email);

        return $this->render('user/index.html.twig', [
            'user' => $user,
        ]);
    }

    /**
     * @Route("/userstri", name="user_list")
     */
    public function list(UserRepository $userRepository): Response
    {
        $users = $userRepository->findAllByEmailAsc();

        return $this->render('user/index.html.twig', [
            'users' => $users,
        ]);
    }
    /**
* @Route("/users/search-sort", name="user_search_sort")
*/
public function searchSort(UserRepository $userRepository, Request $request): Response
{
    $action = $request->query->get('action');
    $order = $request->query->get('order');
    $email = $request->query->get('email');

    if ($action == 'search') {
        $users = $userRepository->findByEmail($email);
    } else {
        $users = $userRepository->findAllSorted($order);
    }

    return $this->render('user/index.html.twig', [
        'users' => $users,
    ]);
}
}



    