<?php

namespace App\Controller;

use App\Entity\ParkingSpace;
use App\Form\ParkingSpaceType;
use App\Repository\ParkingSpaceRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\PositiveOrZero;
#[Route('/parking/space')]
class ParkingSpaceController extends AbstractController
{
    #[Route('/', name: 'app_parking_space_index', methods: ['GET'])]
    public function index(ParkingSpaceRepository $parkingSpaceRepository, Request $request): Response
    {
        $queryBuilder = $parkingSpaceRepository->createQueryBuilder('ps');
        $type = $request->query->get('type');
        if ($type !== null) {
            $queryBuilder
                ->andWhere('ps.type = :type')
                ->setParameter('type', $type);
        }
        
        $sort = $request->query->get('sort');
        switch ($sort) {
            case 'asc':
                $queryBuilder->orderBy('ps.nombrePlace', 'ASC');
                break;
            case 'desc':
                $queryBuilder->orderBy('ps.nombrePlace', 'DESC');
                break;
            default:
                $queryBuilder->orderBy('ps.nombrePlace', 'ASC');
                break;
        }
        
        $parkingSpaces = $queryBuilder->getQuery()->getResult();
        
        return $this->render('parking_space/index.html.twig', [
            'parking_spaces' => $parkingSpaces,
        ]);
        
    }
    


    #[Route('/new', name: 'app_parking_space_new', methods: ['GET', 'POST'])]
public function new(Request $request, ParkingSpaceRepository $parkingSpaceRepository): Response
{
    $parkingSpace = new \App\Entity\ParkingSpace();
    $form = $this->createForm(ParkingSpaceType::class, $parkingSpace);
    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        $parkingSpaceRepository->save($parkingSpace, true);

        return $this->redirectToRoute('app_parking_space_index', [], Response::HTTP_SEE_OTHER);
    }

    return $this->renderForm('parking_space/new.html.twig', [
        'parking_space' => $parkingSpace,
        'form' => $form,
    ]);
}

    #[Route('/{id}', name: 'app_parking_space_show', methods: ['GET'])]
    public function show(ParkingSpace $parkingSpace): Response
    {
        return $this->render('parking_space/show.html.twig', [
            'parking_space' => $parkingSpace,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_parking_space_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, ParkingSpace $parkingSpace, ParkingSpaceRepository $parkingSpaceRepository): Response
    {
        $form = $this->createForm(ParkingSpaceType::class, $parkingSpace);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $parkingSpaceRepository->save($parkingSpace, true);

            return $this->redirectToRoute('app_parking_space_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('parking_space/edit.html.twig', [
            'parking_space' => $parkingSpace,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_parking_space_delete', methods: ['POST'])]
    public function delete(Request $request, ParkingSpace $parkingSpace, ParkingSpaceRepository $parkingSpaceRepository): Response
    {
        if ($this->isCsrfTokenValid('delete'.$parkingSpace->getId(), $request->request->get('_token'))) {
            $parkingSpaceRepository->remove($parkingSpace, true);
        }

        return $this->redirectToRoute('app_parking_space_index', [], Response::HTTP_SEE_OTHER);
    }


    

}
