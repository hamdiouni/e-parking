<?php

namespace App\Repository;

use App\Entity\Poste;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class PosteRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Poste::class);
    }

    public function findAllOrderedByDate()
    {
        return $this->createQueryBuilder('p')
            ->orderBy('p.date', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function findByNomAuteur($nomAuteur)
    {
        return $this->createQueryBuilder('p')
            ->andWhere('p.nomAuteur = :nomAuteur')
            ->setParameter('nomAuteur', $nomAuteur)
            ->getQuery()
            ->getResult();
    }
}
