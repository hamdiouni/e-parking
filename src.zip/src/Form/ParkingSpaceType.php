<?php

namespace App\Form;

use App\Entity\ParkingSpace;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\PositiveOrZero;

class ParkingSpaceType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('id_place', null, [
                'constraints' => [
                    new NotBlank(['message' => 'L\'identifiant de la place est obligatoire'])
                ]
            ])
            ->add('nombre_place', null, [
                'constraints' => [
                    new NotBlank(['message' => 'Le nombre de places est obligatoire']),
                    new PositiveOrZero(['message' => 'Le nombre de places doit être positif ou nul'])
                ]
            ])
            ->add('type', null, [
                'constraints' => [
                    new NotBlank(['message' => 'Le type de la place est obligatoire'])
                ]
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => ParkingSpace::class,
        ]);
    }
}
