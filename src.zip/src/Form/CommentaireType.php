<?php

namespace App\Form;
use App\Utils\BadwordFilter;
use App\Entity\Commentaire;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Callback;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

class CommentaireType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('contenu', TextareaType::class, [
                'label' => 'Commentaire',
                'constraints' => [
                    new Callback([
                        'callback' => function ($value, ExecutionContextInterface $context) use ($options) {
                            // Initialize the badword filter with the list of badwords
                            $badwordFilter = new BadwordFilter($options['badwords']);
                            if ($badwordFilter->hasBadword($value)) {
                                throw new \Exception('Votre message contient un mot interdit.');
                            }
                        },
                    ]),
                ],
            ]);
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Commentaire::class,
            'badwords' => ['bad', 'putain', 'fuck'],
        ]);
    }
}
