<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * Poste
 *
 * @ORM\Table(name="poste")
 * @ORM\Entity
 */
class Poste
{
    public function __construct()
    {
        $this->commentaires =  new ArrayCollection();
    }

    /**
     * @var int
     *
     * @ORM\Column(name="id_poste", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idPoste;

    /**
     * @var string
     *
     * @ORM\Column(name="sujet_poste", type="string", length=200, nullable=false)
     */
    private $sujetPoste;

    /**
     * @var string
     *
     * @ORM\Column(name="nom_auteur", type="string", length=20, nullable=false)
     */
    private $nomAuteur;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date", nullable=false)
     */
    private $date;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Commentaire", mappedBy="poste")
     */
    private $commentaires;



    /**
     * @return mixed
     */
    public function getCommentaires()
    {
        return $this->commentaires;
    }

    /**
     * @param mixed $commentaires
     */
    public function setCommentaires($commentaires): void
    {
        $this->commentaires = $commentaires;
    }


    public function getIdPoste(): ?int
    {
        return $this->idPoste;
    }

    /**
     * @param int $idPoste
     */
    public function setIdPoste(int $idPoste): void
    {
        $this->idPoste = $idPoste;
    }

    public function getSujetPoste(): ?string
    {
        return $this->sujetPoste;
    }

    public function setSujetPoste(string $sujetPoste): self
    {
        $this->sujetPoste = $sujetPoste;

        return $this;
    }

    public function getNomAuteur(): ?string
    {
        return $this->nomAuteur;
    }

    public function setNomAuteur(string $nomAuteur): self
    {
        $this->nomAuteur = $nomAuteur;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }
    /**
     * @ORM\Column(type="integer")
     */
    private $likes = 0;

    /**
     * @ORM\Column(type="integer")
     */
    private $dislikes = 0;

    // ...

    public function getLikes(): ?int
    {
        return $this->likes;
    }

    public function setLikes(int $likes): self
    {
        $this->likes = $likes;

        return $this;
    }

    public function getDislikes(): ?int
    {
        return $this->dislikes;
    }

    public function setDislikes(int $dislikes): self
    {
        $this->dislikes = $dislikes;

        return $this;
    }
}
