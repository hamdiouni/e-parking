<?php

namespace App\Controller;
use App\Entity\TwilioSms;
use Doctrine\ORM\EntityManagerInterface;
use App\Utils\BadwordFilter;
use App\Entity\Reclamation;
use App\Form\ReclamationType;
use App\Repository\ReclamationRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use Knp\Snappy\Pdf;
use Dompdf\Dompdf;
use Dompdf\Options;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Swift_Mailer;
use Swift_Message;
use Swift_SmtpTransport;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;


class ReclamationController extends AbstractController
{
    #[Route('/reclamation', name: 'app_reclamation')]
    public function index(EntityManagerInterface $entityManager): Response
    {
        $reclamations = $entityManager
            ->getRepository(Reclamation::class)
            ->findAll();
        
        usort($reclamations, function($a, $b) {
            return strcmp($a->getNomClient(), $b->getNomClient());
        });
        
        // Debugging statements
        foreach ($reclamations as $reclamation) {
            
        }
        
        return $this->render('reclamation/index.html.twig', [
            'list' => $reclamations
        ]);
    }

   /**
 *  @Route("/create", name="create")
 */
public function create(Request $request)
{        
    $reclamation = new Reclamation(); 
    $form = $this->createForm(ReclamationType::class, $reclamation);
    $form->handleRequest($request);
    
    // Define the list of badwords
    $badwords = ['lol', 'lool', 'loool', 'etat'];
    
    // Initialize the badword filter with the list of badwords
    $badwordFilter = new BadwordFilter($badwords); 
    
    if ($form->isSubmitted() && $form->isValid()) {
        $message = $reclamation->getEtat();
        // Check if the message contains any badwords
        if ($badwordFilter->hasBadword($message)) {
            // Display a custom error message without showing the badword
            $this->addFlash('error', 'Your message contains inappropriate language.');
        } else {
            // Check if the submitted badword is already in the list of badwords
            if (!in_array($message, $badwords)) {
                // Add the badword to the list of badwords
                $badwords[] = $message;
            }
            // Save the reclamation to the database
            $em = $this->getDoctrine()->getManager();
            $em->persist($reclamation);
            $em->flush();

            $this->addFlash('success', 'Your reclamation has been submitted successfully!');
            return $this->redirectToRoute('app_reclamation');
        }
    }
    
    return $this->render('reclamation/create.html.twig', [
        'form' => $form->createView(),
        'badwords' => $badwords,
    ]);
}

    

       /**
 * @Route("/testimonial", name="testimonial")
 */
public function testimonial(Request $request): Response
{
     $reclamation= new Reclamation(); 
        $form= $this->createForm(ReclamationType::class ,$reclamation);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
        $em = $this->getDoctrine()->getManager();
        $em->persist($reclamation);
        $em->flush();
   
        $this->addFlash('notice','Submitted Successfully!!');
        return $this->redirectToRoute('app_reclamation');
        }
    return $this->render('front/testimonial.html.twig',[
           'form' =>$form->createView()]);
    }

       /**
     * @Route("/update/{id}" , name="update")
     * 
     */
    public function update(Request $request, $id){
       
        $reclamation= $this->getDoctrine()->getRepository(Reclamation::class)->find($id); 
        $form= $this->createForm(ReclamationType::class ,$reclamation);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
           
        $em = $this->getDoctrine()->getManager();
        $em->persist($reclamation);
        $em->flush();
   
        $this->addFlash('notice','update Successfully!!');
   
        return $this->redirectToRoute('app_reclamation');
        }
        return $this->render('reclamation/update.html.twig',[
           'form' =>$form->createView()
        ]);

    }
    /**
     *  @Route("/delete/{id}" , name="delete")
     */
    public function delete($id)
{
$data = $this->getDoctrine()->getRepository(Reclamation::class)->find($id);
$em = $this->getDoctrine()->getManager();
$em->remove($data);
$twilio = new TwilioSmS('ACa01431161ce211029db94900843651b3', '5077c03702314d8d6400603b97f6aa0a', '+16813256273');
$twilio->sendSMS('+21650673149', 'nouvelle réclamation supprimé   !');
$em->flush();

$this->addFlash('notice','Deleted Successfully!!');

return $this->redirectToRoute('app_reclamation');
}
/**
     * @Route("/reclamations/{id}", name="reclamation_show", methods={"GET"})
     */
    public function show(int $id, ReclamationRepository $reclamationRepository): Response
    {
        $reclamation = $reclamationRepository->find($id);

        if (!$reclamation) {
            throw $this->createNotFoundException('Réclamation non trouvée');
        }

        return $this->render('reclamation/show.html.twig', [
            'reclamation' => $reclamation,
        ]);
    }
     /**
 * @Route("/search", name="search", methods={"GET"})
 */
public function search(Request $request): Response
{
    // Récupérer le nom saisi dans le formulaire
    $nom_client = $request->query->get('nom_client');

    // Effectuer la recherche en fonction du nom
    // Vous pouvez utiliser votre logique de recherche ici
    $reclamation = $this->getDoctrine()->getRepository(Reclamation::class)->findOneBy(['nom_client' => $nom_client]);

    // Retourner la réponse avec les résultats de la recherche
    return $this->render('reclamation/search.html.twig', [
        'reclamation' => $reclamation,
    ]);
}



  /**
     * @Route("/exportPdf", name="exportPdf")
     */
  
    public function imprime(ReclamationRepository $repository): Response
    {
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
        $dompdf = new Dompdf($pdfOptions);
        $reclamations= $repository->findAll();
        $html = $this->renderView('reclamation/pdf.html.twig', [
            'reclamations' => $reclamations,
        ]);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $dompdf->stream("Liste des reclamations.pdf", [
            "Attachment" => true
        ]);
        return $this->redirectToRoute('app_readR');
    }
     
 
    /*public function email ($user,$mailer){
        // Create a new SMTP transport with the desired configuration
    $dsn = getenv('MAILER_DSN');
    $transport = new Swift_SmtpTransport('smtp.gmail.com', 587, 'tls');
    $transport->setUsername('fakhfakh4321@gmail.com');
    $transport->setPassword('22122000lool');

    $mailer = new Swift_Mailer($transport);

    //BUNDLE MAILER
    $message = (new Swift_Message('Confirmation reservation'))
        ->setFrom('fakhfakh4321@gmail.com')
        ->setTo($user->getEmail())
        ->setBody(" Bonjour,\n \nNous vous confirmons votre réservation pour l'événement");

    //send mail
    $mailer->send($message);
    }*/


}
