<?php

namespace App\Controller;

use App\Entity\Vehicule;
use App\Form\VehiculeType;
use App\Repository\VehiculeRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Dompdf\Dompdf;
use Mpdf\Mpdf;

use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class VehiculeController extends AbstractController
{
     /**
 * @Route("/vehicules", name="vehicule_index", methods={"GET"})
 */
public function index(VehiculeRepository $VehiculeRepository ,Request $request): Response
{
    $qb = $VehiculeRepository->createQueryBuilder('v');
    
    // Filtre par marque
    $marque = $request->query->get('marque');
    if ($marque) {
        $qb->andWhere('v.marque = :marque')
           ->setParameter('marque', $marque);
    }
    
    // Filtre par couleur
    $couleur = $request->query->get('couleur');
    if ($couleur) {
        $qb->andWhere('v.couleur = :couleur')
           ->setParameter('couleur', $couleur);
    }
    $matricule = $request->query->get('matricule');
    if ($matricule) {
        $qb->andWhere('v.matricule = :matricule')
           ->setParameter('matricule', $matricule);
    }
    
    // Filtre par categorievoiture
    $categorievoiture = $request->query->get('categorievoiture');
    if ($categorievoiture) {
        $qb->andWhere('v.categorievoiture = :categorievoiture')
           ->setParameter('categorievoiture', $categorievoiture);
    }
    
    // Filtre par modele
    $modele = $request->query->get('modele');
    if ($modele) {
        $qb->andWhere('v.modele = :modele')
           ->setParameter('modele', $modele);
    }
    
    // Tri par matricule
    $tri = $request->query->get('tri');
    if ($tri && in_array($tri, ['asc', 'desc'])) {
        $qb->orderBy('v.matricule', $tri);
    }
    
    $vehicules = $qb->getQuery()->getResult();

    return $this->render('vehicule/index.html.twig', [
        'vehicules' => $vehicules,
    ]);
}
public function generatePdf(VehiculeRepository $VehiculeRepository, Request $request)
{
    // Récupérer les résultats de la requête
    $qb = $VehiculeRepository->createQueryBuilder('v');

    // Ajouter les filtres et le tri
    // ...

    $vehicules = $qb->getQuery()->getResult();

    // Générer le contenu HTML
    $html = $this->renderView('vehicule/pdf.html.twig', [
        'vehicules' => $vehicules,
    ]);

    // Créer l'objet mPDF et générer le PDF
    $mpdf = new Mpdf();
    $mpdf->WriteHTML($html);
    $mpdf->Output('liste_vehicules.pdf', 'D');

    // Note : la méthode Output() avec le deuxième paramètre à "D" permet de télécharger directement le PDF
}

   /**
 * @Route("/vehicules/new", name="vehicule_new", methods={"GET","POST"})
 */
public function new(Request $request): Response
{
    $vehicule = new Vehicule();
    $form = $this->createForm(VehiculeType::class, $vehicule);
    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        $matricule = $vehicule->getMatricule();
        if (preg_match('/^\d+[A-Z]{3}\d+$/', $matricule) !== 1) {
            $this->addFlash('error', 'Le matricule doit contenir des chiffres à gauche et à droite de "TUN".');
            return $this->redirectToRoute('vehicule_new');
        }
        $entityManager = $this->getDoctrine()->getManager();
        try {
            $entityManager->persist($vehicule);
            $entityManager->flush();
            $this->addFlash('success', 'Le véhicule a été ajouté avec succès.');
            return $this->redirectToRoute('vehicule_index');
        } catch (UniqueConstraintViolationException $e) {
            $this->addFlash('error', 'Le matricule existe déjà dans la base de données.');
            return $this->redirectToRoute('vehicule_new');
        }
    }

    return $this->render('vehicule/new.html.twig', [
        'vehicule' => $vehicule,
        'form' => $form->createView(),
    ]);
}



    /**
     * @Route("/vehicules/{matricule}", name="vehicule_show", methods={"GET"})
     */
    public function show(string $matricule): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $vehicule = $entityManager->getRepository(Vehicule::class)->findOneBy(['matricule' => $matricule]);

        if (!$vehicule) {
            throw $this->createNotFoundException(
                'Aucun véhicule trouvé avec le matricule '.$matricule
            );
        }

        return $this->render('vehicule/show.html.twig', [
            'vehicule' => $vehicule,
        ]);
    }

    /**
 * @Route("/vehicules/{matricule<^[A-Za-z0-9]+$>}/edit", name="vehicule_edit", methods={"GET","POST"})
 */
    public function edit(Request $request, string $matricule): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $vehicule = $entityManager->getRepository(Vehicule::class)->findOneBy(['matricule' => $matricule]);

        if (!$vehicule) {
            throw $this->createNotFoundException(
                'Aucun véhicule trouvé avec le matricule '.$matricule
            );
        }

        $form = $this->createForm(VehiculeType::class, $vehicule);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('vehicule_index');
        }

        return $this->render('vehicule/edit.html.twig', [
            'vehicule' => $vehicule,
            'form' => $form->createView(),
        ]);
    }

/**
 * @Route("/vehicules/{matricule}", name="vehicule_delete", methods={"POST"})
 */
public function delete(Request $request, string $matricule): Response
{
    $entityManager = $this->getDoctrine()->getManager();
    $vehicule = $entityManager->getRepository(Vehicule::class)->findOneBy(['matricule' => $matricule]);

    if (!$vehicule) {
        throw $this->createNotFoundException(
            'Aucun véhicule trouvé avec le matricule '.$matricule
        );
    }

    $entityManager->remove($vehicule);
    $entityManager->flush();

    return $this->redirectToRoute('vehicule_index');
}


/**
 * @Route("/vehicules/search", name="vehicule_search", methods={"GET"})
 */
/*public function search(Request $request): Response
{
    $matricule = $request->query->get('matricule');

    $entityManager = $this->getDoctrine()->getManager();
    $vehicule = $entityManager->getRepository(Vehicule::class)->findOneBy(['matricule' => $matricule]);
    
    if (!$vehicule) {
        $this->addFlash('error', 'Aucun véhicule trouvé avec le matricule ' . $matricule);
        return $this->redirectToRoute('vehicule_index');
    }
    
    return $this->render('vehicule/index.html.twig', [
        'vehicule' => [$vehicule], // passing as array to match the previous implementation
    ]);
}*/









/**
 * @Route("/vehicules/sort", name="vehicule_sort", methods={"GET"})
 */
/*public function sort(Request $request): Response
{
    $sortType = $request->query->get('sortType');

    $entityManager = $this->getDoctrine()->getManager();
    $vehicules = $entityManager->getRepository(Vehicule::class)->findBy([], ['marque' => $sortType]);

    return $this->render('vehicule/index.html.twig', [
        'vehicules' => $vehicules,
    ]);
}*/

/**
 * @Route("/vehicules/searchByMarque", name="vehicule_searchByMarque", methods={"GET"})
 */
/*public function searchByMarque(Request $request): Response
{
    $marque = $request->query->get('marque');

    $entityManager = $this->getDoctrine()->getManager();
    $vehicules = $entityManager->getRepository(Vehicule::class)->createQueryBuilder('v')
        ->where('v.marque LIKE :marque')
        ->setParameter('marque', '%'.$marque.'%')
        ->getQuery()
        ->getResult();

    return $this->render('vehicule/index.html.twig', [
        'vehicules' => $vehicules,
    ]);
}*/


/**
 * @Route("/statistiques", name="vehicule_statistiques")
 */
public function statistiques(EntityManagerInterface $entityManager)
{
    // Compter le nombre total de voitures dans la table
    $totalCount = $entityManager->getRepository(Vehicule::class)->count([]);

    // Grouper les voitures par catégorie et compter le nombre de voitures dans chaque groupe
    $categoryCounts = $entityManager->createQueryBuilder()
        ->select('v.categorievoiture, COUNT(v.matricule) as count')
        ->from(Vehicule::class, 'v')
        ->groupBy('v.categorievoiture')
        ->getQuery()
        ->getResult();

    return $this->render('vehicule/statistiques.html.twig', [
        'totalCount' => $totalCount,
        'categoryCounts' => $categoryCounts,
    ]);
}
/**
 * @Route("/vehicules/pdf", name="vehicule_pdf", methods={"GET"})
 */
/*public function pdfList(): Response
{
    // Retrieve the list of vehicles
    $vehicules = $this->getDoctrine()
        ->getRepository(Vehicule::class)
        ->findAll();

    // Create a new PDF document
    $pdf = new Dompdf();

    // Generate the HTML content for the PDF
    $html = $this->renderView('vehicule/pdf.html.twig', [
        'vehicules' => $vehicules,
    ]);

    // Load the HTML content into the PDF document
    $pdf->loadHtml($html);

    // Set the paper size and orientation
    $pdf->setPaper('A4', 'portrait');

    // Add a custom CSS file
    $css = file_get_contents('css/vehicule-pdf.css');
    $pdf->getOptions()->setIsRemoteEnabled(true);
    $pdf->setOptions([
        'isPhpEnabled' => true,
        'isRemoteEnabled' => true,
    ]);
    $pdf->add_css($css);

    // Render the PDF document
    $pdf->render();

    // Generate the response object
    $response = new Response($pdf->output(), Response::HTTP_OK, [
        'Content-Type' => 'application/pdf',
        'Content-Disposition' => 'attachment; filename="vehicules.pdf"',
    ]);

    return $response;
}*/
}

