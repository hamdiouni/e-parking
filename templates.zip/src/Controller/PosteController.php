<?php
namespace App\Controller;
 use App\Form\PosteType;
use App\Entity\Poste;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


class PosteController extends AbstractController
{


    /**
     * @Route("/poste/{id}/like", name="post_like")
     */
    public function like($id)
    {
        // Get the post by its id from the database
        $post = $this->getDoctrine()->getRepository(Poste::class)->find($id);

        if (!$post) {
            throw $this->createNotFoundException('The post does not exist');
        }

        // Increment the like count for the post
        $post->setLikes($post->getLikes() + 1);

        // Save the changes to the database
        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->flush();

        // Redirect the user back to the post page
        return $this->redirectToRoute('poste_show', ['id' => $id]);
    }

    /**
     * @Route("/poste/{postId}/dislike", name="post_dislike")
     */
    public function dislike($postId)
    {
        // Get the post by its id from the database
        $post = $this->getDoctrine()->getRepository(Poste::class)->find($postId);

        if (!$post) {
            throw $this->createNotFoundException('The post does not exist');
        }

        // Decrement the like count for the post
        $post->setDislikes($post->getDislikes() + 1);

        // Save the changes to the database
        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->flush();

        // Redirect the user back to the post page
        return $this->redirectToRoute('poste_show', ['id' => $postId]);
    }

    /**
     * @Route("/", name="poste_index", methods={"GET"})
     */
    public function index(Request $request): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $posteRepository = $entityManager->getRepository(Poste::class);
        if ($request->query->get('sort') == 'likes_asc')
            $postes = $posteRepository->findBy(array(), array('likes' => 'ASC'));
        else if ($request->query->get('sort') == 'likes_desc')
            $postes = $posteRepository->findBy(array(), array('likes' => 'DESC'));
        else
            $postes = $posteRepository->findAll();

        return $this->render('poste/index.html.twig', [
            'postes' => $postes,
            'sort' => $request->query->get('sort'),
        ]);
    }

    /**
     * @Route("/new", name="poste_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $poste = new Poste();
        $form = $this->createForm(PosteType::class, $poste);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($poste);
            $entityManager->flush();

            return $this->redirectToRoute('poste_index');
        }

        return $this->render('poste/new.html.twig', [
            'poste' => $poste,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="poste_show", methods={"GET"})
     */
    public function show(Poste $poste, Request $request): Response
    {
        return $this->render('poste/show.html.twig', [
            'poste' => $poste,
            'isAdmin' => $request->query->get('isAdmin')
        ]);
    }

    /**
     * @Route("/{id}/edit", name="poste_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Poste $poste): Response
    {
        $form = $this->createForm(PosteType::class, $poste);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('poste_index');
        }

        return $this->render('poste/edit.html.twig', [
            'poste' => $poste,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="poste_delete", methods={"POST"})
     */
    public function delete(Request $request, Poste $poste): Response
    {
        if ($this->isCsrfTokenValid('delete' . $poste->getIdPoste(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($poste);
            $entityManager->flush();
        }

        return $this->redirectToRoute('poste_index');
    }
}
