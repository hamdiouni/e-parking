<?php

namespace App\Repository;

use App\Entity\Vehicule;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\QueryBuilder;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Request;

/**
 * @method Vehicule|null find($id, $lockMode = null, $lockVersion = null)
 * @method Vehicule|null findOneBy(array $criteria, array $orderBy = null)
 * @method Vehicule[]    findAll()
 * @method Vehicule[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class VehiculeRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Vehicule::class);
    }

    public function countAll()
    {
        return $this->createQueryBuilder('v')
            ->select('COUNT(v.matricule)')
            ->getQuery()
            ->getSingleScalarResult();
    }

    public function countByCategory()
    {
        return $this->createQueryBuilder('v')
            ->select('v.categorievoiture, COUNT(v.matricule) as count')
            ->groupBy('v.categorievoiture')
            ->getQuery()
            ->getResult();
    }
    public function findAll(): array
{
    return $this->createQueryBuilder('v')
        ->orderBy('v.matricule', 'ASC')
        ->getQuery()
        ->getResult()
    ;
}
public function findByMarque($marque)
{
    return $this->createQueryBuilder('v')
        ->andWhere('v.marque = :marque')
        ->setParameter('marque', $marque)
        ->orderBy('v.id', 'ASC')
        ->getQuery()
        ->getResult()
    ;
}

public function findAllOrderedByMatricule($order = 'ASC')
{
    return $this->createQueryBuilder('v')
        ->orderBy('v.matricule', $order)
        ->getQuery()
        ->getResult()
    ;
}
public function findAllFilteredAndSorted(Request $request): array
{
    $qb = $this->createQueryBuilder('v');

    $qb = $this->applyFilters($qb, $request);
    $qb = $this->applySorting($qb, $request);

    return $qb->getQuery()->getResult();
}

private function applyFilters(QueryBuilder $qb, Request $request): QueryBuilder
{
    $marque = $request->query->get('marque');
    if ($marque) {
        $qb->andWhere('v.marque = :marque')
            ->setParameter('marque', $marque);
    }

    $couleur = $request->query->get('couleur');
    if ($couleur) {
        $qb->andWhere('v.couleur = :couleur')
            ->setParameter('couleur', $couleur);
    }

    $categorievoiture = $request->query->get('categorievoiture');
    if ($categorievoiture) {
        $qb->andWhere('v.categorievoiture = :categorievoiture')
            ->setParameter('categorievoiture', $categorievoiture);
    }

    $modele = $request->query->get('modele');
    if ($modele) {
        $qb->andWhere('v.modele = :modele')
            ->setParameter('modele', $modele);
    }

    return $qb;
}

private function applySorting(QueryBuilder $qb, Request $request): QueryBuilder
{
    $tri = $request->query->get('tri');
    if ($tri && in_array($tri, ['asc', 'desc'])) {
        $qb->orderBy('v.matricule', $tri);
    }

    return $qb;
}
}
