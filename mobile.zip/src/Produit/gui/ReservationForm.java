package Produit.gui;

import com.codename1.io.ConnectionRequest;
import com.codename1.io.NetworkManager;
import com.codename1.ui.Button;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;
import java.util.Hashtable;
import com.codename1.io.ConnectionRequest;
import com.codename1.ui.TextArea;
import com.codename1.ui.layouts.BorderLayout;
import com.mycompany.entities.ParkingSpace;
import com.mycompany.entities.Reservation;
import com.mycompany.myapp.entities.services.ServiceParkingSpace;
//import javax.net.ssl.SSLException;



import com.mycompany.myapp.entities.services.ServiceReservation;
public class ReservationForm extends Form {
    private int idPlace;
    private ServiceReservation sr;
    private ServiceParkingSpace sp;
    private TextField prixField, dureeField;
    private Button addButton;
    public boolean resultOk;

    public ReservationForm(int id_place) {
        super("Réserver");
        this.idPlace = id_place;
            this.sr=new ServiceReservation();
            this.sp = new ServiceParkingSpace();
        // Initialisation des champs de texte et du bouton "Add"
        prixField = new TextField("", "Prix");
        dureeField = new TextField("", "Durée");
        addButton = new Button("Réserver");

        // Ajout des composants au formulaire
        this.setLayout(new BoxLayout(BoxLayout.Y_AXIS));
        this.add(prixField);
        this.add(dureeField);
        this.add(addButton);

        // Ajout d'un listener sur le bouton "Add"
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                addPlace();
            }
        });
    }

  private void addPlace() {
    // Récupération des valeurs des champs de texte
    int prix = Integer.parseInt(prixField.getText());
    String duree = dureeField.getText();

    // Création d'un objet hashtable pour stocker les paramètres de la requête
    Hashtable params = new Hashtable();
    params.put("prix", prix);
    params.put("duree", duree);
    System.out.println("In ReservationForm : idPlace is :" + idPlace);
    ParkingSpace parkingSpace;
    parkingSpace = sp.read(idPlace);
    System.out.println("In ReservationForm : parkingSpace.idPlace is : " + parkingSpace.getIdPlace());
    Reservation ps = new Reservation(parkingSpace, prix, duree);
    System.out.println("In ReservationForm : Reservation.place.idPlace is : " + ps.getPlace().getIdPlace());
    boolean status = this.sr.create(ps);
    if(status){
        resultOk = true;
        Dialog d = new Dialog("Info");
        TextArea popupBody = new TextArea("Réservation ajouté avec succés", 3, 10);
        popupBody.setUIID("PopupBody");
        popupBody.setEditable(false);
        d.setLayout(new BorderLayout());
        d.add(BorderLayout.CENTER, popupBody);
        d.showPopupDialog(addButton);
        ParkingListFront pl = new ParkingListFront();
        pl.show();
    }
    // Envoi de la requête HTTP avec les paramètres
    /*String url = BASE_URL + "/users/add_json";
    ConnectionRequest req = new ConnectionRequest();
    //req.setCertificateValidationMode(ConnectionRequest.CERTIFICATE_VALIDATION_DISABLED); // Désactivation de la validation de certificat
    req.setUrl(url);
    req.setPost(true);
    req.setContentType("application/x-www-form-urlencoded");
    //req.setRequestBody(HttpUtil.encodeParams(params));
    req.addResronseListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            // Affichage du message de confirmation de création de l'utilisateur
            String message = "User created successfully!";
            Dialog.show("Success", message, "OK", null);

            // Effacement des champs de texte
            prixField.setText("");
            emailField.setText("");
            dureeField.setText("");
        }
    });
    
    // Désactiver la validation de certificat
   /* req.setSslVerifier(new SslCertificate() {
        public boolean verify(String hostname, byte[] certData) throws SSLException {
            return true;
        }
    });*/
    
   // NetworkManager.getInstance().addToQueue(req);*/
}//



}
