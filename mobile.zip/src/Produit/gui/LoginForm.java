package Produit.gui;

import com.codename1.io.ConnectionRequest;
import com.codename1.io.NetworkManager;
import com.codename1.ui.Button;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;
import java.util.Hashtable;
import com.codename1.io.ConnectionRequest;
import com.codename1.ui.TextArea;
import com.codename1.ui.layouts.BorderLayout;
//import javax.net.ssl.SSLException;



import com.mycompany.myapp.entities.services.ServiceUser;
public class LoginForm extends Form {
    private ServiceUser su;
    private TextField usernameField, emailField, passwordField;
    private Button loginButton;

    public LoginForm() {
        super("Login");
            this.su=new ServiceUser();
        // Initialisation des champs de texte et du bouton "Add"
        usernameField = new TextField("", "Username");
        passwordField = new TextField("", "Password", 20, TextField.PASSWORD);
        loginButton = new Button("Login");

        // Ajout des composants au formulaire
        this.setLayout(new BoxLayout(BoxLayout.Y_AXIS));
        this.add(usernameField);
        this.add(passwordField);
        this.add(loginButton);

        // Ajout d'un listener sur le bouton "Add"
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                login();
            }
        });
    }

  private void login() {
    // Récupéprivateration des valeurs des champs de texte
    String username = usernameField.getText();
    String password = passwordField.getText();

    // Création d'un objet hashtable pour stocker les paramètres de la requête
    Hashtable params = new Hashtable();
    params.put("username", username);
    params.put("password", password);
 
    Boolean status = this.su.login(usernameField, passwordField);
    if(status){
        Dialog d = new Dialog("Info");
        TextArea popupBody = new TextArea("Login successfull", 3, 10);
        popupBody.setUIID("PopupBody");
        popupBody.setEditable(false);
        d.setLayout(new BorderLayout());
        d.add(BorderLayout.CENTER, popupBody);
        d.showPopupDialog(loginButton);
        this.showHomepageForm();
        } else {
    // If login is unsuccessful, show error message
    Dialog d = new Dialog("Error");
    TextArea popupBody = new TextArea("Invalid username or password", 3, 10);
    popupBody.setUIID("PopupBody");
    popupBody.setEditable(false);
    d.setLayout(new BorderLayout());
    d.add(BorderLayout.CENTER, popupBody);
    d.showPopupDialog(loginButton);
}
    }
  public void showHomepageForm() {
    // Create a new form for the homepage
    Form home = new Form("home");

    // Add components to the form
    // ...

    // Show the form
    home.show();
}

    // Envoi de la requête HTTP avec les paramètres
    /*String url = BASE_URL + "/users/add_json";
    ConnectionRequest req = new ConnectionRequest();
    //req.setCertificateValidationMode(ConnectionRequest.CERTIFICATE_VALIDATION_DISABLED); // Désactivation de la validation de certificat
    req.setUrl(url);
    req.setPost(true);
    req.setContentType("application/x-www-form-urlencoded");
    //req.setRequestBody(HttpUtil.encodeParams(params));
    req.addResponseListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            // Affichage du message de confirmation de création de l'utilisateur
            String message = "User created successfully!";
            Dialog.show("Success", message, "OK", null);

            // Effacement des champs de texte
            usernameField.setText("");
            emailField.setText("");
            passwordField.setText("");
        }
    });
    
    // Désactiver la validation de certificat
   /* req.setSslVerifier(new SslCertificate() {
        public boolean verify(String hostname, byte[] certData) throws SSLException {
            return true;
        }
    });*/
    
   // NetworkManager.getInstance().addToQueue(req);*/
}//




