package Produit.gui;

import com.codename1.ui.Button;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Display;
import com.codename1.ui.Form;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.GridLayout;
import com.mycompany.entities.ParkingSpace;
import Produit.gui.ParkingSpaceCardGUI;
import com.mycompany.myapp.entities.services.ServiceParkingSpace;


import java.util.ArrayList;

public class ParkingList {
    private ServiceParkingSpace sp;
    private Form mainForm;
    private ArrayList<ParkingSpaceCardGUI> parkingSpaceCards = new ArrayList<>();

    public ParkingList() {
        this.sp = new ServiceParkingSpace();
        ArrayList<ParkingSpace> parkingSpaces = this.sp.readAll();
        // create the main form
        mainForm = new Form("List of Parking Spaces");
        mainForm.setLayout(new BorderLayout());
        Button addButton = new Button("Ajouter place");
       // create the card container
        Container cardContainer = new Container();
        cardContainer.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        // add the cards to the card container
        for (ParkingSpace parkingSpace : parkingSpaces) {
            ParkingSpaceCardGUI parkingSpaceCard = new ParkingSpaceCardGUI(parkingSpace);
            parkingSpaceCards.add(parkingSpaceCard);
            cardContainer.add(parkingSpaceCard.getCardContainer());
            cardContainer.add(ComponentGroup.enclose(new Spacer()));
        }
        addButton.addActionListener(e -> addButtonHandler());
        // create the scrollable container
        Container scrollableContainer = new Container();
        scrollableContainer.setLayout(new GridLayout(1, 1));
        scrollableContainer.add(addButton);
        scrollableContainer.add(cardContainer);
        scrollableContainer.isScrollableY();
        // Create a ScrollPane and set its content to myContainer

// Add the scrollPane to a parent container or to the current form
        // add the scrollable container to the main form
        mainForm.addComponent(BorderLayout.CENTER, scrollableContainer);
    }

    public void show() {
        mainForm.show();
    }

    private void addButtonHandler() {
        PlaceForm pf = new PlaceForm();
        pf.show();//To change body of generated methods, choose Tools | Templates.
    }

    // helper class to group Components together
    private static class ComponentGroup extends Container {
        private ComponentGroup(Component... components) {
            super(new BoxLayout(BoxLayout.Y_AXIS));
            for (Component component : components) {
                add(component);
            }
        }

        public static ComponentGroup enclose(Component... components) {
            return new ComponentGroup(components);
        }
    }

    // helper class to create empty space
    private static class Spacer extends Container {
        private Spacer() {
            super();
            setLayout(new BoxLayout(BoxLayout.Y_AXIS));
            setUIID("Spacer");
            setPreferredH(10);
        }
    }
}
