package Produit.gui;

import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.GridLayout;
import com.mycompany.entities.ParkingSpace;
import Produit.gui.ParkingSpaceCardGUIFront;
import com.mycompany.myapp.entities.services.ServiceParkingSpace;

import java.util.ArrayList;

public class ParkingListFront {
    private ServiceParkingSpace sp;
    private Form mainForm;
    private ArrayList<ParkingSpaceCardGUIFront> parkingSpaceCards = new ArrayList<>();

    public ParkingListFront() {
        this.sp = new ServiceParkingSpace();
        ArrayList<ParkingSpace> parkingSpaces = this.sp.readAll();
        // create the main form
        mainForm = new Form("List of Parking Spaces");
        mainForm.setLayout(new BorderLayout());

        // create the card container
        Container cardContainer = new Container();
        cardContainer.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        // add the cards to the card container
        for (ParkingSpace parkingSpace : parkingSpaces) {
            ParkingSpaceCardGUIFront parkingSpaceCard = new ParkingSpaceCardGUIFront(parkingSpace);
            parkingSpaceCards.add(parkingSpaceCard);
            cardContainer.add(parkingSpaceCard.getCardContainer());
            cardContainer.add(ComponentGroup.enclose(new Spacer()));
        }

        // create the scrollable container
        Container scrollableContainer = new Container();
        scrollableContainer.setLayout(new GridLayout(1, 1));
        scrollableContainer.add(cardContainer);

        // add the scrollable container to the main form
        mainForm.addComponent(BorderLayout.CENTER, scrollableContainer);
    }

    public void show() {
        mainForm.show();
    }

    // helper class to group Components together
    private static class ComponentGroup extends Container {
        private ComponentGroup(Component... components) {
            super(new BoxLayout(BoxLayout.Y_AXIS));
            for (Component component : components) {
                add(component);
            }
        }

        public static ComponentGroup enclose(Component... components) {
            return new ComponentGroup(components);
        }
    }

    // helper class to create empty space
    private static class Spacer extends Container {
        private Spacer() {
            super();
            setLayout(new BoxLayout(BoxLayout.Y_AXIS));
            setUIID("Spacer");
            setPreferredH(10);
        }
    }
}
