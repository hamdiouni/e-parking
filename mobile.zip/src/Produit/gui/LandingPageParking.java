/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Produit.gui;

import com.codename1.ui.Button;
import com.codename1.ui.Form;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;

public class LandingPageParking extends Form {

    public LandingPageParking() {
        super("Landing Page Parking");
        this.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        // Add Login button
        Button loginButton = new Button("Back");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                ParkingList loginForm = new ParkingList();
                loginForm.show();
            }
        });
        this.addComponent(loginButton);

        // Add Register button
        Button registerButton = new Button("Front");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                ParkingListFront userForm = new ParkingListFront();
                userForm.show();
            }
        });
        this.addComponent(registerButton);
    }
}
