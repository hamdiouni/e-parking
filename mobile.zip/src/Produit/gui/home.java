/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Produit.gui;
import com.mycomany.entities.Reclamation;
import Produit.gui.ListReclamationForm;

import com.codename1.ui.Button;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.util.Resources;
import com.mycompany.gui.BaseForm;

/**
 *
 * @author 21621
 */
public class home extends BaseForm{
    
    public home(Resources res){
        super(new FlowLayout(CENTER, CENTER));
        
        Button closeButton = new Button("Post");
closeButton.addActionListener(e -> 
        new AllPoste(res).show()

);
 Button closeButton2 = new Button("LandingPost");
closeButton.addActionListener(e -> 
        new LandingPage().show()

);
 Button closeButton3 = new Button("Liste Vehicule");
closeButton.addActionListener(e -> 
{
    

 
                    new ListVehiculesForm(this,res).show();
      
       
}
);


 Button closeButton4 = new Button("Liste Vehicule Front");
closeButton.addActionListener(e -> 
{
    

 
                    new ListVehiculesUserForm(this,res).show();
      
       
}
);
 Button closeButton5 = new Button("Liste reclamation");
closeButton.addActionListener(e -> 
{
    

 
                    new ListReponseForm(theme).show();
      
       
}
);
// Button closeButton = new Button("Post");
//closeButton.addActionListener(e -> 
//        new AllPoste(res).show()
//
//);
// Button closeButton = new Button("Post");
//closeButton.addActionListener(e -> 
//        new AllPoste(res).show()
//
//);
// Button closeButton = new Button("Post");
//closeButton.addActionListener(e -> 
//        new AllPoste(res).show()
//
//);
// Button closeButton = new Button("Post");
//closeButton.addActionListener(e -> 
//        new AllPoste(res).show()
//
//);
// Button closeButton = new Button("Post");
//closeButton.addActionListener(e -> 
//        new AllPoste(res).show()
//
//);
// Button closeButton = new Button("Post");
//closeButton.addActionListener(e -> 
//        new AllPoste(res).show()
//
//);
// Button closeButton = new Button("Post");
//closeButton.addActionListener(e -> 
//        new AllPoste(res).show()
//
//);
// Button closeButton = new Button("Post");
//closeButton.addActionListener(e -> 
//        new AllPoste(res).show()
//
//);

this.addAll(closeButton,closeButton2,closeButton3,closeButton4,closeButton5);
    }
    
    
}
