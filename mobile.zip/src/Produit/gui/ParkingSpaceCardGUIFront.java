/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Produit.gui;

import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.FontImage;
import com.codename1.ui.Label;
import com.codename1.ui.TextArea;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.mycompany.entities.ParkingSpace;
import com.mycompany.myapp.entities.services.ServiceParkingSpace;

public class ParkingSpaceCardGUIFront {
    private Container cardContainer;
    private ParkingSpace parkingSpace;
    private ServiceParkingSpace sp;

    public ParkingSpaceCardGUIFront(ParkingSpace parkingSpace) {
        this.parkingSpace = parkingSpace;
        this.sp = new ServiceParkingSpace();
        createCard();
    }

    private void createCard() {
        // create the card container
        cardContainer = new Container(new BorderLayout());
        cardContainer.setUIID("Card");

        // create the card header
        Container header = new Container(new BoxLayout(BoxLayout.X_AXIS));
        header.setUIID("CardHeader");

        Label typeLabel = new Label(parkingSpace.getType());
        Label placeIdLabel = new Label(String.valueOf(parkingSpace.getIdPlace()));
        Label nombrePlacesLabel = new Label(String.valueOf(parkingSpace.getNombrePlace()));

        header.add(typeLabel);
        header.add(placeIdLabel);
        header.add(nombrePlacesLabel);

        cardContainer.addComponent(BorderLayout.NORTH, header);

        // create the card footer
        Container footer = new Container(new BoxLayout(BoxLayout.X_AXIS));
        footer.setUIID("CardFooter");
        
        Button resButton = new Button("Réserver");
        resButton.addActionListener(e ->{ boolean status = réserverPlace();
        if(status){
        Dialog d = new Dialog("Info");
        TextArea popupBody = new TextArea("Réservé avec succés", 3, 10);
        popupBody.setUIID("PopupBody");
        popupBody.setEditable(false);
        d.setLayout(new BorderLayout());
        d.add(BorderLayout.CENTER, popupBody);
        d.showPopupDialog(resButton);
        cardContainer.getParent().removeComponent(cardContainer);
        
        }});

        footer.add(resButton);

        cardContainer.addComponent(BorderLayout.SOUTH, footer);
    }

    private boolean réserverPlace() {
        System.out.println("In ParkingSpaceCardGUIFront : parkingSpace.idPlace is : " + parkingSpace.getId());
        ReservationForm updateForm = new ReservationForm(parkingSpace.getId());
        updateForm.show();
        return updateForm.resultOk;
        
        
    }


    public Container getCardContainer() {
        return cardContainer;
    }

}
