package Produit.gui;

import com.codename1.io.ConnectionRequest;
import com.codename1.io.NetworkManager;
import com.codename1.ui.Button;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;
import java.util.Hashtable;
import com.codename1.io.ConnectionRequest;
//import javax.net.ssl.SSLException;



import com.mycompany.myapp.entities.services.ServiceUser;
public class UserForm extends Form {
    private ServiceUser su;
    private TextField usernameField, emailField, passwordField;
    private Button addButton;
    public static final String BASE_URL = "https://127.0.0.1:8000";

    public UserForm() {
        super("Add User");
            this.su=new ServiceUser();
        // Initialisation des champs de texte et du bouton "Add"
        usernameField = new TextField("", "Username");
        emailField = new TextField("", "Email");
        passwordField = new TextField("", "Password", 20, TextField.PASSWORD);
        addButton = new Button("Add");

        // Ajout des composants au formulaire
        this.setLayout(new BoxLayout(BoxLayout.Y_AXIS));
        this.add(usernameField);
        this.add(emailField);
        this.add(passwordField);
        this.add(addButton);

        // Ajout d'un listener sur le bouton "Add"
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                addUser();
            }
        });
    }

  private void addUser() {
    // Récupération des valeurs des champs de texte
    String username = usernameField.getText();
    String email = emailField.getText();
    String password = passwordField.getText();

    // Création d'un objet hashtable pour stocker les paramètres de la requête
    Hashtable params = new Hashtable();
    params.put("username", username);
    params.put("email", email);
    params.put("password", password);
 
    this.su.ajouter(usernameField, emailField, passwordField);
    // Envoi de la requête HTTP avec les paramètres
    /*String url = BASE_URL + "/users/add_json";
    ConnectionRequest req = new ConnectionRequest();
    //req.setCertificateValidationMode(ConnectionRequest.CERTIFICATE_VALIDATION_DISABLED); // Désactivation de la validation de certificat
    req.setUrl(url);
    req.setPost(true);
    req.setContentType("application/x-www-form-urlencoded");
    //req.setRequestBody(HttpUtil.encodeParams(params));
    req.addResponseListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            // Affichage du message de confirmation de création de l'utilisateur
            String message = "User created successfully!";
            Dialog.show("Success", message, "OK", null);

            // Effacement des champs de texte
            usernameField.setText("");
            emailField.setText("");
            passwordField.setText("");
        }
    });
    
    // Désactiver la validation de certificat
   /* req.setSslVerifier(new SslCertificate() {
        public boolean verify(String hostname, byte[] certData) throws SSLException {
            return true;
        }
    });*/
    
   // NetworkManager.getInstance().addToQueue(req);*/
}//



}
