package Produit.gui;

import com.codename1.io.ConnectionRequest;
import com.codename1.io.NetworkManager;
import com.codename1.ui.Button;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;
import java.util.Hashtable;
import com.codename1.io.ConnectionRequest;
import com.codename1.ui.TextArea;
import com.codename1.ui.layouts.BorderLayout;
import com.mycompany.entities.ParkingSpace;
//import javax.net.ssl.SSLException;



import com.mycompany.myapp.entities.services.ServiceParkingSpace;
public class PlaceUpdateForm extends Form {
    private ServiceParkingSpace sp;
    private ParkingSpace parkingSpace;
    private TextField nombrePlaceField, idPlaceField, typeField;
    private Button addButton;

    public PlaceUpdateForm(ParkingSpace ps) {
        
        super("Modifier Place");
        this.parkingSpace = ps;
            this.sp=new ServiceParkingSpace();
        // Initialisation des champs de texte et du bouton "Add"
        nombrePlaceField = new TextField(""+parkingSpace.getNombrePlace(), "Nombre de places");
        idPlaceField = new TextField(""+parkingSpace.getIdPlace(), "Id Place");
        typeField = new TextField(parkingSpace.getType(), "Type de véhicules");
        addButton = new Button("Modifier");

        // Ajout des composants au formulaire
        this.setLayout(new BoxLayout(BoxLayout.Y_AXIS));
        this.add(nombrePlaceField);
        this.add(idPlaceField);
        this.add(typeField);
        this.add(addButton);

        // Ajout d'un listener sur le bouton "Add"
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                modifierPlace();
            }
        });
    }

  private void modifierPlace() {
    // Récupération des valeurs des champs de texte
    int nombrePlace = Integer.parseInt(nombrePlaceField.getText());
    int idPlace = Integer.parseInt(idPlaceField.getText());
    String type = typeField.getText();

    // Création d'un objet hashtable pour stocker les paramètres de la requête
    Hashtable params = new Hashtable();
    params.put("nombrePlace", nombrePlace);
    params.put("idPlace", idPlace);
    ParkingSpace ps = new ParkingSpace(parkingSpace.getId(), idPlace, nombrePlace, type, parkingSpace.getReservations());
    boolean status = this.sp.edit(ps);
    if(status){
        Dialog d = new Dialog("Info");
        TextArea popupBody = new TextArea("Place modifié avec succés", 3, 10);
        popupBody.setUIID("PopupBody");
        popupBody.setEditable(false);
        d.setLayout(new BorderLayout());
        d.add(BorderLayout.CENTER, popupBody);
        d.showPopupDialog(addButton);
        ParkingList p = new ParkingList();
        p.show();
    }
    // Envoi de la requête HTTP avec les paramètres
    /*String url = BASE_URL + "/users/add_json";
    ConnectionRequest req = new ConnectionRequest();
    //req.setCertificateValidationMode(ConnectionRequest.CERTIFICATE_VALIDATION_DISABLED); // Désactivation de la validation de certificat
    req.setUrl(url);
    req.setPost(true);
    req.setContentType("application/x-www-form-urlencoded");
    //req.setRequestBody(HttpUtil.encodeParams(params));
    req.addResponseListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            // Affichage du message de confirmation de création de l'utilisateur
            String message = "User created successfully!";
            Dialog.show("Success", message, "OK", null);

            // Effacement des champs de texte
            nombrePlaceField.setText("");
            emailField.setText("");
            idPlaceField.setText("");
        }
    });
    
    // Désactiver la validation de certificat
   /* req.setSslVerifier(new SslCertificate() {
        public boolean verify(String hostname, byte[] certData) throws SSLException {
            return true;
        }
    });*/
    
   // NetworkManager.getInstance().addToQueue(req);*/
}//



}
