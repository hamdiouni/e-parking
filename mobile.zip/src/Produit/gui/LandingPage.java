/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Produit.gui;

import com.codename1.ui.Button;
import com.codename1.ui.Form;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;

public class LandingPage extends Form {

    public LandingPage() {
        super("Landing Page");
        this.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        // Add Login button
        Button loginButton = new Button("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                LoginForm loginForm = new LoginForm();
                loginForm.show();
            }
        });
        this.addComponent(loginButton);

        // Add Register button
        Button registerButton = new Button("Register");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                UserForm userForm = new UserForm();
                userForm.show();
            }
        });
        this.addComponent(registerButton);
    }
}
