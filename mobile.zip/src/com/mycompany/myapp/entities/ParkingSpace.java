/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.entities;

/**
 *
 * @author USER
 */
public class ParkingSpace {
    private int id;
    private int idPlace;
    private int nombrePlace;
    private String type;
    private Reservation reservations;

    public ParkingSpace() {
    }
 public ParkingSpace( int idPlace, int nombrePlace, String type) {

        this.idPlace = idPlace;
        this.nombrePlace = nombrePlace;
        this.type = type;
    }
    public ParkingSpace(int id, int idPlace, int nombrePlace, String type, Reservation reservations) {
        this.id = id;
        this.idPlace = idPlace;
        this.nombrePlace = nombrePlace;
        this.type = type;
        this.reservations = reservations;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdPlace() {
        return idPlace;
    }

    public void setIdPlace(int idPlace) {
        this.idPlace = idPlace;
    }

    public int getNombrePlace() {
        return nombrePlace;
    }

    public void setNombrePlace(int nombrePlace) {
        this.nombrePlace = nombrePlace;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Reservation getReservations() {
        return reservations;
    }

    public void setReservations(Reservation reservations) {
        this.reservations = reservations;
    }
    
}
