/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myapp.entities;

/**
 *
 * @author Wael
 */
public class Vehicule {
      private String matricule;

    private String marque;
    private String modele;
    private String couleur;
    private String categorievoiture;

    public Vehicule(String matricule, String marque, String modele, String couleur, String categorievoiture) {
        this.matricule = matricule;
        this.marque = marque;
        this.modele = modele;
        this.couleur = couleur;
        this.categorievoiture = categorievoiture;
    }

    public Vehicule() {
    }

    public String getMatricule() {
        return matricule;
    }

    public String getMarque() {
        return marque;
    }

    public String getModele() {
        return modele;
    }

    public String getCouleur() {
        return couleur;
    }

    public String getCategorievoiture() {
        return categorievoiture;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    public void setCouleur(String couleur) {
        this.couleur = couleur;
    }

    public void setCategorievoiture(String categorievoiture) {
        this.categorievoiture = categorievoiture;
    }

    @Override
    public String toString() {
        return "Vehicule{" + "matricule=" + matricule + ", marque=" + marque + ", modele=" + modele + ", couleur=" + couleur + ", categorievoiture=" + categorievoiture + '}';
    }
    
        
}
