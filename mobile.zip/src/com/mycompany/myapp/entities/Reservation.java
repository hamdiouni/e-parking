/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.entities;

/**
 *
 * @author USER
 */
public class Reservation {
    private int id;
    private ParkingSpace place;
    private float prix;
    private String duree;
    public Reservation(){}
    public Reservation( ParkingSpace place, float prix, String duree) {

        this.place = place;
        this.prix = prix;
        this.duree = duree;
    }
    public Reservation(int id, ParkingSpace place, float prix, String duree) {
        this.id = id;
        this.place = place;
        this.prix = prix;
        this.duree = duree;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ParkingSpace getPlace() {
        return place;
    }

    public void setPlace(ParkingSpace place) {
        this.place = place;
    }

    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public String getDuree() {
        return duree;
    }

    public void setDuree(String duree) {
        this.duree = duree;
    }
    
}
