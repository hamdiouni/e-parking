/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myapp.entities.services;

import java.util.ArrayList;
import java.util.Set;

/**
 *
 * @author USER
 */
public interface IService<T> {
    
    
    
    boolean create(T t);
    boolean delete(int t);
    boolean edit(T t);
    T read(int id);
    ArrayList<T> readAll();
    
    
}
