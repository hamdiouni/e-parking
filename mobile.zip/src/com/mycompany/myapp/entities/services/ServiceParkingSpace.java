package com.mycompany.myapp.entities.services;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkEvent;
import com.codename1.io.NetworkManager;
import com.codename1.ui.events.ActionListener;
import com.mycompany.entities.ParkingSpace;
import com.mycompany.entities.ParkingSpace;
import com.mycompany.myapp.utils.Statics;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ServiceParkingSpace implements IService<ParkingSpace>{
 public static ServiceParkingSpace instance = null ;
    
    public static boolean resultOk = false;

    //initilisation connection request 
    private ConnectionRequest req;
    
    public ServiceParkingSpace(){
        req = new ConnectionRequest();
    }
    public static ServiceParkingSpace getInstance() {
        if(instance == null )
            instance = new ServiceParkingSpace();
        return instance;
    }
    
    public boolean create(ParkingSpace t) {
        String url = Statics.BASE_URL+"/parking_json/space/new?nombre_place="+t.getNombrePlace()+"&id_place="+t.getIdPlace()+"&type="+t.getType();
    
    req.setUrl(url);
    req.setPost(false);
    req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOk = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
       NetworkManager.getInstance().addToQueueAndWait(req);
       return resultOk;
    }

    public boolean delete(int id) {
        String url = Statics.BASE_URL+"/parking_json_delete/space/"+id;
    
    req.setUrl(url);
    req.setPost(false);
    req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOk = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
       NetworkManager.getInstance().addToQueueAndWait(req);
       return resultOk;
    }

    
    public boolean edit(ParkingSpace t) {
        String url = Statics.BASE_URL+"/parking_json_edit/"+t.getId()+"/edit?nombre_place="+t.getNombrePlace()+"&id_place="+t.getIdPlace()+"&type="+t.getType();
    
    req.setUrl(url);
    req.setPost(false);
    req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOk = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
       NetworkManager.getInstance().addToQueueAndWait(req);
       return resultOk;
    }

    
    public ParkingSpace read(int id) {
        String url = Statics.BASE_URL+"/parking_json/space/"+id;
    ParkingSpace parkingSpace = new ParkingSpace();
    req.setUrl(url);
    req.setPost(false);
    req.addResponseListener(new ActionListener<NetworkEvent>() {
        
            @Override
            public void actionPerformed(NetworkEvent evt) {
                JSONParser jsonp ;
                jsonp = new JSONParser();
                
                try {
                    Map<String, Object> parsedMap = jsonp.parseJSON(new InputStreamReader(new ByteArrayInputStream(req.getResponseData())));
                    float idPlace = Float.parseFloat(parsedMap.get("idPlace").toString());
                    float nombrePlace = Float.parseFloat(parsedMap.get("nombrePlace").toString());
parkingSpace.setType((String) parsedMap.get("type"));
parkingSpace.setIdPlace((int) idPlace);
parkingSpace.setNombrePlace((int) nombrePlace);
System.out.println("In ServiceParkingSpace.read.actionPerformed : parkingSpace.idPlace : " + parkingSpace.getIdPlace());
                } catch (IOException ex) {
                   System.out.println(ex.getMessage());
                }
                resultOk = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
       NetworkManager.getInstance().addToQueueAndWait(req);
       System.out.println("In ServiceParkingSpace.read : parkingSpace.idPlace : " + parkingSpace.getIdPlace());
       return parkingSpace;
       
    
    }

    
    public ArrayList<ParkingSpace> readAll() {
        ArrayList<ParkingSpace> result = new ArrayList<>();
        
        String url = Statics.BASE_URL+"/parking_json_all";
        req.setUrl(url);
        req.setPost(false);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                JSONParser jsonp ;
                jsonp = new JSONParser();
                
                try {
                    Map<String,Object>mapParkingSpaces = jsonp.parseJSON(new CharArrayReader(new String(req.getResponseData()).toCharArray()));
                    
                    List<Map<String,Object>> listOfMaps =  (List<Map<String,Object>>) mapParkingSpaces.get("root");
                    
                    for(Map<String, Object> obj : listOfMaps) {
                        ParkingSpace re = new ParkingSpace();
                        
                        //dima id fi codename one float 5outhouha
                        float id = Float.parseFloat(obj.get("id").toString());
                        
                        float idPlace = Float.parseFloat(obj.get("idPlace").toString());
                        float nombrePlace = Float.parseFloat(obj.get("nombrePlace").toString());
                        String type = obj.get("type").toString();
                        

                        
                        
                        re.setId((int)id);
                        re.setIdPlace((int)idPlace);
                        re.setNombrePlace((int)nombrePlace);
                        re.setType(type);
                     
    
                        //insert data into ArrayList result
                        result.add(re);
                       
                    
                    }
                    
                }catch(Exception ex) {
                    
                    ex.printStackTrace();
                }
            
            }
        });
        
      NetworkManager.getInstance().addToQueueAndWait(req);//execution ta3 request sinon yet3ada chy dima nal9awha

        return result;
    }
    
}