/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myapp.entities.services;

import com.codename1.io.ConnectionRequest;
import com.codename1.io.NetworkEvent;
import com.codename1.io.NetworkManager;
import com.codename1.ui.Dialog;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionListener;
import com.mycompany.myapp.utils.Statics;
import com.mycompany.entities.User;

/**
 *
 * @author 21621
 */
public class ServiceUser {
   public static ServiceUser instance = null;
   public boolean resultOk = true;
   private ConnectionRequest req;
  public static ServiceUser getInstance(){
      if(instance ==null)
          instance = new ServiceUser ();
      return instance ;
  }
    public ServiceUser(){
        req = new ConnectionRequest();
        
    }   
    public   void ajouter(TextField username,TextField email,TextField password)
    {
        String url =Statics.BASE_URL+"/users/add_json?username="+username.getText().toString()+"&email="+email.getText().toString()+"&password="+password.getText().toString();
        
        req.setUrl(url);
        
       if(username.getText().equals(" ")&&password.getText().equals(" ")&&email.getText().equals(" "))
       {Dialog.show("Erreur","veullez remplir les champs","ok", null);
           
           
       }   
       req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOk = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
       NetworkManager.getInstance().addToQueueAndWait(req);
       
    }
    public boolean login(TextField username, TextField password){
        System.out.println(username.getText().toString() +"          "+password.getText().toString());
        System.out.println("ENtered");
        String url =Statics.BASE_URL+"/users_json_login?username="+username.getText().toString()+"&password="+password.getText().toString();
        System.out.println("URL =="+url);
        req.setUrl(url);
        req.setPost(false);
        System.out.println("STARTING");
       if(username.getText().equals(" ")&&password.getText().equals(" "))
       {Dialog.show("Erreur","veullez remplir les champs","ok", null);
           
           
       }   
       req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOk = req.getResponseCode() == 200; //Code HTTP 200 OK
                String data = new String(req.getResponseData());
                req.removeResponseListener(this);
            }
        });
       NetworkManager.getInstance().addToQueueAndWait(req);
       return resultOk;
    }
}
