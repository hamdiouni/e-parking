package com.mycompany.myapp.entities.services;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkEvent;
import com.codename1.io.NetworkManager;
import com.codename1.ui.events.ActionListener;
import com.mycompany.entities.ParkingSpace;
import com.mycompany.entities.Reservation;
import com.mycompany.entities.Reservation;
import com.mycompany.entities.Reservation;
import com.mycompany.myapp.utils.Statics;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ServiceReservation implements IService<Reservation>{
 public static ServiceReservation instance = null ;
    private ServiceParkingSpace ps;
    public static boolean resultOk = false;

    //initilisation connection request 
    private ConnectionRequest req;
    
    public ServiceReservation(){
        this.ps = new ServiceParkingSpace();
        req = new ConnectionRequest();
    }
    public static ServiceReservation getInstance() {
        if(instance == null )
            instance = new ServiceReservation();
        return instance;
    }
    
    public boolean create(Reservation t) {
        System.out.println(t.getPlace().getId());
        String url = Statics.BASE_URL+"/res_json_new?place_id="+t.getPlace().getIdPlace()+"&prix="+t.getPrix()+"&duree="+t.getDuree();
    
    req.setUrl(url);
    req.setPost(false);
    req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOk = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
       NetworkManager.getInstance().addToQueueAndWait(req);
       return resultOk;
    }

    public boolean delete(int id) {
        String url = Statics.BASE_URL+"/res_json_delete/"+id;
    
    req.setUrl(url);
    req.setPost(false);
    req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOk = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
       NetworkManager.getInstance().addToQueueAndWait(req);
       return resultOk;
    }

    public boolean edit(Reservation t) {
        String url = Statics.BASE_URL+"/res_json_edit/"+t.getId()+"?id_place="+t.getPlace().getId()+"&prix="+t.getPrix()+"&duree="+t.getDuree();
    
    req.setUrl(url);
    req.setPost(false);
    req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOk = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
       NetworkManager.getInstance().addToQueueAndWait(req);
       return resultOk;
    }

    public Reservation read(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public ArrayList<Reservation> readAll() {
        ArrayList<Reservation> result = new ArrayList<>();
        
        String url = Statics.BASE_URL+"/res_json";
        req.setUrl(url);
        req.setPost(false);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                JSONParser jsonp ;
                jsonp = new JSONParser();
                
                try {
                    Map<String,Object>mapReservations = jsonp.parseJSON(new CharArrayReader(new String(req.getResponseData()).toCharArray()));
                    
                    List<Map<String,Object>> listOfMaps =  (List<Map<String,Object>>) mapReservations.get("root");
                    
                    for(Map<String, Object> obj : listOfMaps) {
                        Reservation re = new Reservation();
                        
                        //dima id fi codename one float 5outhouha
                        float id = Float.parseFloat(obj.get("id").toString());
                        
                        float place = Float.parseFloat(obj.get("place").toString());
                        float prix = Float.parseFloat(obj.get("prix").toString());
                        String duree = obj.get("duree").toString();
                        
                        ParkingSpace placeObj = ps.read((int)place);
                        
                        
                        re.setId((int)id);
                        re.setPlace(placeObj);
                        re.setPrix(prix);
                        re.setDuree(duree);
                     
    
                        //insert data into ArrayList result
                        result.add(re);
                       
                    
                    }
                    
                }catch(Exception ex) {
                    
                    ex.printStackTrace();
                }
            
            }
        });
        
      NetworkManager.getInstance().addToQueueAndWait(req);//execution ta3 request sinon yet3ada chy dima nal9awha

        return result;
    }
    
}