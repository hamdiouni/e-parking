/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myapp.services;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkEvent;
import com.codename1.io.NetworkManager;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionListener;
import com.mycompany.myapp.entities.Vehicule;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 *
 * @author rihem
 */
public class ServiceVehicule {
    public ArrayList<Vehicule> lists;
    public static ServiceVehicule instance ; 
    public boolean resultOK;
    private  ConnectionRequest req; 
 public static final String BASE_URL="http://127.0.0.1:8000/api";
 private ServiceVehicule() {
        req = new ConnectionRequest() ; 
         }
    /* Singleton patron de conception de creation */
    public static ServiceVehicule getInstance() {
        if (instance == null)
        {
            instance = new ServiceVehicule();
        }
         return instance;
    }
 
 public ArrayList<Vehicule> parseEntitie(String jsonText){
        try {
            lists= new ArrayList<>();
            JSONParser j = new JSONParser();
            Map<String,Object> CategorieListJson = j.parseJSON(new CharArrayReader(jsonText.toCharArray()));
           List< Map<String,Object>> list =(List< Map<String,Object>>) CategorieListJson.get("root");
          
           for ( Map<String,Object> obj: list){
            
                
               Vehicule c = new Vehicule();
            
             c.setCouleur(obj.get("couleur").toString());
             c.setMatricule(obj.get("matricule").toString());
             c.setMarque(obj.get("marque").toString());
            c.setModele(obj.get("modele").toString());
                 c.setCategorievoiture(obj.get("categorievoiture").toString());
            
            
             lists.add(c);
         
        } }
           catch (IOException ex) {
             
        }
          return lists;
 }
     public ArrayList<Vehicule> getAll(){
          String url = BASE_URL+"/listVehicule";
        req.setUrl(url);
        req.setPost(false);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                lists = parseEntitie(new String(req.getResponseData()));
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
        return lists;
    }
        public void Supprimer(String id) {
        ConnectionRequest con = new ConnectionRequest();
        con.setUrl(BASE_URL+"/deleteVehicule/"+id);
        con.setPost(false);
        con.addResponseListener((evt) -> {
            System.out.println(con.getResponseData());

        });
        NetworkManager.getInstance().addToQueueAndWait(con);

    }
       public boolean add (TextField tfMarque,TextField tfModele,
       TextField tfCouleur,
       TextField tfMatricule,
       TextField tfCateogorie){
           
       String url = BASE_URL+"/addVehicule?marque="+tfMarque.getText()+"&modele="+tfModele.getText()+"&couleur="+tfCouleur.getText()+"&matricule="+tfMatricule.getText()+"&categorie="+tfCateogorie.getText();
       req.setUrl(url);
       req.addResponseListener(new ActionListener<NetworkEvent>(){ 
           @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOK = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
             }
    });
        System.out.println(""+resultOK);
       NetworkManager.getInstance().addToQueue(req);
        return resultOK;
    }
           public boolean edit (TextField tfMarque,TextField tfModele,
       TextField tfCouleur,
       TextField tfMatricule,
       TextField tfCateogorie)
    { 

       String url = BASE_URL+"/editVehicule/"+tfMatricule+"?marque="+tfMarque.getText()+"&modele="+tfModele.getText()+"&couleur="+tfCouleur.getText()+"&matricule="+tfMatricule.getText()+"&categorie="+tfCateogorie.getText();
       req.setUrl(url);
       req.addResponseListener(new ActionListener<NetworkEvent>(){ 
           @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOK = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
             }
    });
        System.out.println(""+resultOK);
       NetworkManager.getInstance().addToQueue(req);
        return resultOK;
    }

}

