/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myapp.entities.services;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkEvent;
import com.codename1.io.NetworkManager;
import com.codename1.l10n.SimpleDateFormat;
import com.codename1.messaging.Message;
import com.codename1.ui.events.ActionListener;
import com.mycompany.myapp.entities.Poste;

import com.mycompany.myapp.utils.Statics;
import java.io.IOException;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author azizbramli
 */
public class ServicePoste {
    
    
    public ArrayList<Poste> Postes;
    
    public static ServicePoste instance=null;
    public boolean resultOK;
    private ConnectionRequest req;
    public ServicePoste() {
         req = new ConnectionRequest();
    }

    public static ServicePoste getInstance() {
        if (instance == null) {
            instance = new ServicePoste();
        }
        return instance;
    }
    


   public ArrayList<Poste> parsePostes(String jsonText){
    try {
        System.out.println(jsonText);
        Postes=new ArrayList<>();
        JSONParser j = new JSONParser();
        Map<String,Object> tasksListJson = j.parseJSON(new CharArrayReader(jsonText.toCharArray()));
        List<Map<String,Object>> list = (List<Map<String,Object>>)tasksListJson.get("root");
        for(Map<String,Object> obj : list){
            System.out.println("Starting Postes Map , Service Postes");
            Poste a = new Poste();
            Object id_poste_obj = obj.get("idPoste");
            if (id_poste_obj != null) {
                a.setId_poste((int)Float.parseFloat(id_poste_obj.toString()));
            }
            Object sujet_poste_obj = obj.get("sujetPoste");
            if (sujet_poste_obj != null) {
                a.setSujet_poste(sujet_poste_obj.toString());
            }
            Object nom_auteur_obj = obj.get("nomAuteur");
            if (nom_auteur_obj != null) {
                a.setNom_auteur(nom_auteur_obj.toString());
            }
            Object date_obj = obj.get("date");
            if (date_obj != null) {
                a.setDate(date_obj.toString());
            }
            Object likes_obj = obj.get("likes");
            if (likes_obj != null) {
                a.setLikes((int)Float.parseFloat(likes_obj.toString()));
            }
            Object dislikes_obj = obj.get("dislikes");
            if (dislikes_obj != null) {
                a.setDislikes((int)Float.parseFloat(dislikes_obj.toString()));
            }
            System.out.println("Singular Post  "+a);
            Postes.add(a);
        }
    } catch (IOException ex) {
    }
    return Postes;
}

    public ArrayList<Poste> getAllPostes(){
        String url = Statics.BASE_URL+"/Allposte";
        System.out.println("this is my all postes");
        req.setUrl(url);
        req.setPost(false); 
        req.addResponseListener(new com.codename1.ui.events.ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                System.out.println("staring");
                Postes = parsePostes(new String(req.getResponseData()));
                req.removeResponseListener(this);
            }
        });
        com.codename1.io.NetworkManager.getInstance().addToQueueAndWait(req);
        System.out.println("Postess ==="+Postes);
        return Postes;
    }

   

    public boolean addPoste(Poste u) {
       String url = "http://127.0.0.1:8000/addposteJSON/new?sujet_poste=" + u.getSujet_poste() + "&nom_auteur=" + u.getNom_auteur() + "&date=" + u.getDate() + "&likes=" + u.getLikes() + "&dislikes=" + u.getDislikes();
       
    
        req.setUrl(url);
        req.setPost(false);
        //req.addArgument("title", f.getTitle());

      
               System.out.println(url);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOK = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
        return resultOK;
    }

    
    
    
    
    
        public boolean editPoste(Poste u) {
           
      String url = "http://127.0.0.1:8000/updateposteJSON/"+u.getId_poste()  + "?sujet_poste=" + u.getSujet_poste() + "&nom_auteur=" + u.getNom_auteur() + "&date=" + u.getDate() + "&likes=" + u.getLikes() + "&dislikes=" + u.getDislikes();
               req.setUrl(url);
               req.setPost(false); 
               System.out.println(url);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOK = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
        return resultOK;
    }
        
        

    public boolean deletePoste(int id) {
        String url = "http://127.0.0.1:8000/deleteposteJSON/" + id;
               req.setUrl(url);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOK = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
        return resultOK;
    }
    public boolean dislike(Poste u) {
           
      String url = "http://127.0.0.1:8000/updatedislike/"+u.getId_poste()   + "?dislikes=" + u.getDislikes();
               req.setUrl(url);
               req.setPost(false); 
               System.out.println(url);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOK = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
        return resultOK;
    }

      public boolean like(Poste u) {
           
      String url = "http://127.0.0.1:8000/updatelike/"+u.getId_poste()   + "?likes=" + u.getLikes();
               req.setUrl(url);
               req.setPost(false); 
               System.out.println(url);
        req.addResponseListener(new ActionListener<NetworkEvent>() {
            @Override
            public void actionPerformed(NetworkEvent evt) {
                resultOK = req.getResponseCode() == 200; //Code HTTP 200 OK
                req.removeResponseListener(this);
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(req);
        return resultOK;
    }
   
    
}
