/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myapp.entities;

import java.util.Date;

/**
 *
 * @author azizbramli
 */
public class Poste {
    int id_poste;
    String sujet_poste,nom_auteur;
    String date;
    int likes,dislikes;

    public Poste() {
    }

    public Poste(int id_poste, String sujet_poste, String nom_auteur, String date, int likes, int dislikes) {
        this.id_poste = id_poste;
        this.sujet_poste = sujet_poste;
        this.nom_auteur = nom_auteur;
        this.date = date;
        this.likes = likes;
        this.dislikes = dislikes;
    }

    public Poste(String sujet_poste, String nom_auteur, String date, int likes, int dislikes) {
        this.sujet_poste = sujet_poste;
        this.nom_auteur = nom_auteur;
        this.date = date;
        this.likes = likes;
        this.dislikes = dislikes;
    }

    public Poste(String sujet_poste, String nom_auteur, String date) {
        this.sujet_poste = sujet_poste;
        this.nom_auteur = nom_auteur;
        this.date = date;
    }
    


    public int getId_poste() {
        return id_poste;
    }

    public String getSujet_poste() {
        return sujet_poste;
    }

    public String getNom_auteur() {
        return nom_auteur;
    }

    public String getDate() {
        return date;
    }

    public int getLikes() {
        return likes;
    }

    public int getDislikes() {
        return dislikes;
    }

    public void setId_poste(int id_poste) {
        this.id_poste = id_poste;
    }

    public void setSujet_poste(String sujet_poste) {
        this.sujet_poste = sujet_poste;
    }

    public void setNom_auteur(String nom_auteur) {
        this.nom_auteur = nom_auteur;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public void setDislikes(int dislikes) {
        this.dislikes = dislikes;
    }

    @Override
    public String toString() {
        return "Poste{" + "id_poste=" + id_poste + ", sujet_poste=" + sujet_poste + ", nom_auteur=" + nom_auteur + ", date=" + date + ", likes=" + likes + ", dislikes=" + dislikes + '}';
    }
    
    
    
}
